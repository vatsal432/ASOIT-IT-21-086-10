document.write(Math.sqrt(49),"<br/>");
document.write(Math.abs(5.2),"<br/>");
document.write(Math.ceil(9.2),"<br/>");
document.write(Math.floor(4.9),"<br/>");
document.write(Math.pow(2,10),"<br/>");
document.write(Math.sin(90),"<br/>");
document.write(Math.cos(0),"<br/>");
document.write(Math.tan(45),"<br/>");

document.write("<br/>","Time & Zone","<br/>");
document.write("<br/>");

var d=new Date();
document.write(d.getDate(),"<br/>");
document.write(d.getDay(),"<br/>");
document.write(d.getMonth(),"<br/>");
document.write(d.getHours(),"<br/>");
document.write(d.getFullYear(),"<br/>");
document.write(d.getMinutes(),"<br/>");
document.write(d.getSeconds(),"<br/>");
document.write(d.getTime(),"<br/>");